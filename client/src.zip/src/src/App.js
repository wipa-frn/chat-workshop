import React, { Component } from 'react';
import 'skeleton-css/css/normalize.css';
import 'skeleton-css/css/skeleton.css';
import './App.css';
import {
  handleInput,
  connectToChatkit,
  connectToRoom,
  sendMessage
} from './methods';
import FormLogin from './components/FormLogin.js'
import RoomList from './components/RoomList.js'
import UserLogin from './components/UserLogin.js'
import UserList from './components/UserList.js'
import UserLogout from './components/UserLogout.js'
import GroupDropDown from './components/GroupDropDown.js'
import ChatSession from './components/ChatSession.js'
import { Button } from 'react-bootstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {faPaperPlane} from '@fortawesome/free-solid-svg-icons'

class App extends Component {
  constructor() {
    super();
    this.state = {
      userId: '',
      showLogin: true,
      isLoading: false,
      currentUser: null,
      currentRoom: null,
      rooms: [],
      roomUsers: [],
      roomName: null,
      messages: [],
      newMessage: '',
    };

    this.handleInput = handleInput.bind(this);
    this.connectToChatkit = connectToChatkit.bind(this);
    this.connectToRoom = connectToRoom.bind(this);
    this.sendMessage = sendMessage.bind(this);
    
  }

  render() {
    const {
      userId,
      showLogin,
      rooms,
      currentRoom,
      currentUser,
      messages,
      newMessage,
      roomUsers,
      roomName,
    } = this.state;

    return (
  
    //chat screen
     <div className="App">
        {currentUser ? (
          <aside className="sidebar left-sidebar">
            <header className="room-header">
              <UserLogin userName={currentUser.name} userId={currentUser.id}></UserLogin>
            </header>

            {currentRoom ? (
              <RoomList 
                rooms={rooms}
                currentRoom={currentRoom}
                connectToRoom={this.connectToRoom}
                currentUser={currentUser}
              />
            ) : null }

            <footer className="bottom-footer">
              <UserLogout></UserLogout>
            </footer>
          </aside>
        ) : null}

        <section className="chat-screen">
          <header className="chat-header">
            {currentRoom ? <GroupDropDown roomName={roomName}></GroupDropDown> : null}
          </header>

          <ul className="chat-messages">
              <ChatSession messages={messages}></ChatSession>
          </ul>

          <footer className="chat-footer">
            <form onSubmit={this.sendMessage} className="message-form">
              <input
                type="text"
                value={newMessage}
                name="newMessage"
                className="message-input"
                placeholder="Type your message and hit ENTER to send"
                onChange={this.handleInput}
              />
              <Button variant="info" type="submit"><FontAwesomeIcon icon={faPaperPlane}></FontAwesomeIcon></Button>
            </form>
          </footer>

        </section>
        <aside className="sidebar right-sidebar">
          {showLogin ? (
            <FormLogin
              userId={userId}
              handleInput={this.handleInput}
              connectToChatkit={this.connectToChatkit}
            />
          ):null}

          {currentRoom ? (
            <UserList currentUser={currentUser} chatUsers={roomUsers}/>
          ) : null }
         
        </aside> 
      </div>
    );
  }
}

export default App;