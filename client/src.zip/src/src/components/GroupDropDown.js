import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {faPlusCircle,faLock ,faComment} from '@fortawesome/free-solid-svg-icons'
import { Button,Dropdown } from 'react-bootstrap';

const GroupDropDown = props =>{
    return(
        <Dropdown>
            <Dropdown.Toggle className="button-group-name" id="dropdown-basic">
                {props.roomName } (3)
            </Dropdown.Toggle>
        
            <Dropdown.Menu>
                <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
                <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
                <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
            </Dropdown.Menu>
        </Dropdown>
    )

}

export default GroupDropDown;