import React,{ Component ,useState} from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {faPlusCircle,faLock ,faComment} from '@fortawesome/free-solid-svg-icons'
import { Badge,Button,Modal,Form } from 'react-bootstrap';
import FormCreateRoom from './FormCreateRoom.js';
import Proptypes from 'prop-types';

const RoomList = props => {

  const { rooms, currentRoom , connectToRoom , currentUser } = props;
  
  // function show room list
  const roomList = rooms.map(room => {
    const roomIcon = !room.isPrivate ? <FontAwesomeIcon icon={faComment} /> : <FontAwesomeIcon icon={faLock} />;
    const isRoomActive = room.id === currentRoom.id ? 'active' : '' ;

    return(
      <li className="room-name"
          key = {room.id}
          onClick={() => connectToRoom(room.id) }
      >
        <div>{ roomIcon }&nbsp;
          {room.customData && room.customData.isDirectMessage ? (
            room.customData.userIds.filter( id => id !== currentUser.id)[0]
          ) : (
            room.name
          )}
        </div>
        <Badge variant="danger">3</Badge>
      </li>
    )

  });

    return (
      <>
        <nav>
          <ul>
            <ModalCreateRoom/>  
            {roomList}
          </ul>
        </nav>
      </>
    )
};

RoomList.propTypes = {
  rooms: Proptypes.array.isRequired,
  currentRoom: Proptypes.object.isRequired,
  connectToRoom: Proptypes.func.isRequired,
  currentUser: Proptypes.object.isRequired,
};

export default RoomList

class ModalCreateRoom extends React.Component {
  constructor(props, context) {
    super(props, context);

    this.handleShow = this.handleShow.bind(this);
    this.handleClose = this.handleClose.bind(this);

    this.state = {
      show: false,
    };
  }

  handleClose() {
    this.setState({ show: false });
  }

  handleShow() {
    this.setState({ show: true });
  }

  render() {
    return (
      <>
        <li className="room-title-li" onClick={this.handleShow}>
          <div className="title-room">
            <div>Create Room </div>
            <div><FontAwesomeIcon  icon={faPlusCircle} /></div>
          </div>
        </li>
        {/* Modal Crate Room */}
        <Modal show={this.state.show} onHide={this.handleClose} >
          <Modal.Header closeButton>
            <Modal.Title>Create a room</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Form>
              <Form.Group controlId="exampleForm.ControlInput1">
                <Form.Label>Room Name</Form.Label>
                <Form.Control type="text" placeholder="Room Name" />
              </Form.Group>
              <Form.Group controlId="exampleForm.ControlSelect1">
                <Form.Label>Add user to this room</Form.Label>
                <Form.Control as="select">
                  <option>1</option>
                  <option>2</option>
                  <option>3</option>
                  <option>4</option>
                  <option>5</option>
                </Form.Control>
              </Form.Group>
            </Form>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="primary" onClick={this.handleClose}>
              Create
            </Button>
            <Button variant="secondary" onClick={this.handleClose}>
              Cancle
            </Button>
          </Modal.Footer>
        </Modal>
      </>
    );
  }
}