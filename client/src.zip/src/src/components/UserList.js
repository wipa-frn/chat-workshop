import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {faCircle,faUserFriends} from '@fortawesome/free-solid-svg-icons'
import { Badge } from 'react-bootstrap';
import Proptypes from 'prop-types';

const UserList = props => {

    const { chatUsers, currentUser } = props;
    let totalMember = 0;
    let memberOnline = 0;
    let memberOffline = 0;
    
    const users_online = chatUsers.map(user => { 
        
        console.log('1:' +user.presence.state)
        if (user.presence.state === 'online'){
            console.log('2:' +user.presence.state)
            memberOnline++;
            totalMember++;
            return (
                <li className="chat-username" key = {user.id}>
                    <div> {user.name} </div>

                    {user.presence.state === 'online' ? (
                        
                    <FontAwesomeIcon icon={faCircle} color="#6AC957" size="xs"/> 
                    
                    ) : null }
                
                
                    {/* {currentUser.id !== user.id ? (
                    <button
                        title={`Send ${user.name} a direct message`}
                        className="send-dm"
                    >
                        +
                    </button>
                    ) : null} */}
                </li>
            )
        }

            
    })

    const users_offline = chatUsers.map(user => { 
        if (user.presence.state !== 'online'){
            totalMember++;
            memberOffline++;
            return (
                <li className="chat-username" key = {user.id}>
                    <div> {user.name} </div>
                    {user.presence.state !== '' ? (
                    <FontAwesomeIcon icon={faCircle} color="#A4A4A4" size="xs"/> ) : null
                    }
                
                    {/* {currentUser.id !== user.id ? (
                    <button
                        title={`Send ${user.name} a direct message`}
                        className="send-dm"
                    >
                        +
                    </button>
                    ) : null} */}
                </li>

            )
        }
    })
    return (
        <div>
      
            {/* header  */}
            <header className="user-header">
                <h6><FontAwesomeIcon icon={faUserFriends} /> Room Members ({totalMember})</h6>
            </header>

            {/* user list */}
            <ul>


                <li className="room-title-li">
                    <div className="title-room">
                        <div>Online ({memberOnline})</div>
                    </div>
                </li>
                {users_online}
                
                {/* offline */}

                <li className="room-title-li">
                    <div className="title-room">
                        <div>Offline ({memberOffline})</div>
                    </div>
                </li>
                {users_offline}

            </ul>
        </div>
    )
}

UserList.propTypes = {
    chatUsers: Proptypes.array.isRequired,
    currentUser: Proptypes.object.isRequired,
};

export default UserList;