import React from 'react';

const TitleRoom = props =>{
    return(
        <div><h4>{props.roomName }</h4></div>
    )

}

export default TitleRoom;