import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {faLock ,faComment} from '@fortawesome/free-solid-svg-icons'
import { Badge} from 'react-bootstrap';
import Proptypes from 'prop-types';
import ModalCreateRoom from './ModalCreateRoom'
import ModalAddUserToRoom from './ModalAddUserToRoom'

const RoomList = props => {

  const { rooms, currentRoom , connectToRoom , currentUser ,createRoom,addUserToRoom,messages} = props;

  // rooms.map(room=>{
  //   messages.forEach(message => {
  //     if((message.senderId === currentUser.id) && (message.room === room.id)){
  //       room.unreadCount--;
  //     }
  //   });
  //   console.log(room.unreadCount); 
  // })
  
  // function show room list
  const roomList = rooms.map(room => {
    const roomIcon = !room.isPrivate ? <FontAwesomeIcon icon={faComment} /> : <FontAwesomeIcon icon={faLock} />;
    const isRoomActive = room.id === currentRoom.id ? 'active' : '' ;

    if(room.id === currentRoom.id) {
      room.unreadCount = 0;

    } 

    return(
      <li className="room-name"
          key = {room.id}
          onClick={() => connectToRoom(room.id) }
      >
        <div>{ roomIcon }&nbsp;
          {room.customData && room.customData.isDirectMessage ? (
            room.customData.userIds.filter( id => id !== currentUser.id)[0]
          ) : (
            room.name
          )}
        </div>

        { ((room.unreadCount !== 0)) ? (<Badge variant="danger">{room.unreadCount}</Badge>) : null}

      </li>
    )

  });


    return (
      <>
        <nav>
          <ul>
            <ModalCreateRoom createRoom={createRoom} currentUser={currentUser}/>  
            <ModalAddUserToRoom  addUserToRoom={addUserToRoom} currentUser={currentUser}/>  
            {roomList}
          </ul>
        </nav>
      </>
    )
};

RoomList.propTypes = {
  rooms: Proptypes.array.isRequired,
  currentRoom: Proptypes.object.isRequired,
  connectToRoom: Proptypes.func.isRequired,
  currentUser: Proptypes.object.isRequired,
};

export default RoomList


