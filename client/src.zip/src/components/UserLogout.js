import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {faSignOutAlt} from '@fortawesome/free-solid-svg-icons'
const UserLogout = () =>{
    return (
        <div>
            <h5>Log out <FontAwesomeIcon icon={faSignOutAlt} /></h5>
        </div>
    )
}

export default UserLogout;